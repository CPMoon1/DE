PRAGMA foreign_keys = ON;

-- Справочники
CREATE TABLE IF NOT EXISTS roles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS manufacturers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS pickup_points (id INTEGER PRIMARY KEY AUTOINCREMENT, address TEXT UNIQUE NOT NULL);

-- Пользователи
CREATE TABLE IF NOT EXISTS users (
                                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                                     login TEXT UNIQUE NOT NULL,
                                     password TEXT NOT NULL,
                                     full_name TEXT NOT NULL,
                                     role_id INTEGER NOT NULL,
                                     FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT
    );

-- Товары
CREATE TABLE IF NOT EXISTS products (
                                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                                        sku TEXT UNIQUE NOT NULL,
                                        name TEXT NOT NULL,
                                        description TEXT,
                                        category_id INTEGER NOT NULL,
                                        manufacturer_id INTEGER NOT NULL,
                                        supplier_id INTEGER NOT NULL,
                                        unit TEXT NOT NULL,
                                        price REAL NOT NULL CHECK(price >= 0),
    stock_qty INTEGER NOT NULL CHECK(stock_qty >= 0),
    discount REAL NOT NULL DEFAULT 0 CHECK(discount >= 0 AND discount <= 100),
    image_path TEXT DEFAULT './resources/picture.png',
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE RESTRICT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE RESTRICT
    );

-- Заказы
CREATE TABLE IF NOT EXISTS orders (
                                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                                      user_id INTEGER NOT NULL,
                                      pickup_point_id INTEGER NOT NULL,
                                      order_date TEXT NOT NULL,
                                      delivery_date TEXT NOT NULL,
                                      status TEXT NOT NULL DEFAULT 'Новый',
                                      pickup_code TEXT NOT NULL,
                                      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
    FOREIGN KEY (pickup_point_id) REFERENCES pickup_points(id) ON DELETE RESTRICT
    );

-- Позиции заказа
CREATE TABLE IF NOT EXISTS order_items (
                                           id INTEGER PRIMARY KEY AUTOINCREMENT,
                                           order_id INTEGER NOT NULL,
                                           product_sku TEXT NOT NULL,
                                           quantity INTEGER NOT NULL CHECK(quantity > 0),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_sku) REFERENCES products(sku) ON DELETE RESTRICT
    );

-- Базовые роли
INSERT OR IGNORE INTO roles (name) VALUES ('Гость'), ('Авторизированный клиент'), ('Менеджер'), ('Администратор');