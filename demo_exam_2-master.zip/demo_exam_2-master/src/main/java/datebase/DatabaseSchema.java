package datebase;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSchema {
    public static void createTables(Connection conn) throws SQLException {
        Statement stmt = conn.createStatement();

        // 1. Создаём таблицы (IF NOT EXISTS гарантирует, что не упадёт, если они уже есть)
        stmt.execute("CREATE TABLE IF NOT EXISTS roles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)");
        stmt.execute("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)");
        stmt.execute("CREATE TABLE IF NOT EXISTS manufacturers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)");
        stmt.execute("CREATE TABLE IF NOT EXISTS suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)");
        stmt.execute("CREATE TABLE IF NOT EXISTS pickup_points (id INTEGER PRIMARY KEY AUTOINCREMENT, address TEXT UNIQUE NOT NULL)");
        stmt.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, login TEXT UNIQUE NOT NULL, password TEXT NOT NULL, full_name TEXT NOT NULL, role_id INTEGER NOT NULL, FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT)");
        stmt.execute("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT, category_id INTEGER NOT NULL, manufacturer_id INTEGER NOT NULL, supplier_id INTEGER NOT NULL, unit TEXT NOT NULL, price REAL NOT NULL, stock_qty INTEGER NOT NULL, discount REAL DEFAULT 0, image_path TEXT, FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT, FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE RESTRICT, FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE RESTRICT)");
        stmt.execute("CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, pickup_point_id INTEGER NOT NULL, order_date TEXT NOT NULL, delivery_date TEXT NOT NULL, status TEXT DEFAULT 'Новый', pickup_code TEXT NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT, FOREIGN KEY (pickup_point_id) REFERENCES pickup_points(id) ON DELETE RESTRICT)");
        stmt.execute("CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_sku TEXT NOT NULL, quantity INTEGER NOT NULL, FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE, FOREIGN KEY (product_sku) REFERENCES products(sku) ON DELETE RESTRICT)");

        // 2. Добавляем роли, если их нет
        stmt.execute("INSERT OR IGNORE INTO roles (name) VALUES ('Гость'), ('Авторизированный клиент'), ('Менеджер'), ('Администратор')");

        stmt.close();
        System.out.println("✅ Структура БД создана.");
    }
}
