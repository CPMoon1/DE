package service;

import datebase.DBConnection;
import model.Product;
import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseService {
    public User authenticate(String login, String password) {
        String cleanLogin = login.trim();
        String cleanPass = password.trim();

        String sql = "SELECT u.id, u.full_name, r.name as role FROM users u JOIN roles r ON u.role_id = r.id WHERE u.login = ? AND u.password = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, cleanLogin);
            ps.setString(2, cleanPass);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("✅ ВХОД УСПЕШЕН: " + rs.getString("full_name") + " | Роль: " + rs.getString("role"));
                    return new User(rs.getInt("id"), cleanLogin, rs.getString("full_name"), rs.getString("role"));
                } else {
                    System.out.println("❌ ВХОД ОТКАЗАН. Проверьте: login='" + cleanLogin + "', pass='" + cleanPass + "'");
                }
            }
        } catch (SQLException e) {
            System.err.println("⚠️ Ошибка БД при авторизации: " + e.getMessage());
        }
        return null;
    }

    public List<Product> getProducts(String search, String manufacturer) {
        List<Product> res = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT p.id, p.sku, p.name, c.name as cat, p.description, m.name as man, s.name as sup, p.price, p.discount, p.stock_qty, p.unit, p.image_path " +
                        "FROM products p LEFT JOIN categories c ON p.category_id=c.id LEFT JOIN manufacturers m ON p.manufacturer_id=m.id LEFT JOIN suppliers s ON p.supplier_id=s.id WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (search != null && !search.isBlank()) {
            sql.append(" AND (p.name LIKE ? OR p.sku LIKE ? OR p.description LIKE ? OR c.name LIKE ? OR m.name LIKE ?)");
            String s = "%" + search + "%";
            for (int i = 0; i < 5; i++) params.add(s);
        }
        if (manufacturer != null && !"Все производители".equals(manufacturer)) {
            sql.append(" AND m.name = ?"); params.add(manufacturer);
        }
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                res.add(new Product(rs.getInt("id"), rs.getString("sku"), rs.getString("name"),
                        rs.getString("cat"), rs.getString("description"), rs.getString("man"),
                        rs.getString("sup"), rs.getDouble("price"), rs.getDouble("discount"),
                        rs.getInt("stock_qty"), rs.getString("unit"), rs.getString("image_path")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return res;
    }
}
