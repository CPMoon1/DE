import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        // Запускаем JavaFX через отдельный класс, чтобы обойти проверку модулей JDK
        Application.launch(Main.class, args);
    }
}
