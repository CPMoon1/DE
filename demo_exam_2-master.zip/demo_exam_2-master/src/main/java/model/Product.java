package model;

public class Product {
    public final int id; public final String sku, name, category, description;
    public final String manufacturer, supplier, unit, imagePath;
    public final double price, discount; public final int stockQty;

    public Product(int id, String sku, String name, String category, String description,
                   String manufacturer, String supplier, double price, double discount,
                   int stockQty, String unit, String imagePath) {
        this.id = id; this.sku = sku; this.name = name; this.category = category;
        this.description = description; this.manufacturer = manufacturer; this.supplier = supplier;
        this.price = price; this.discount = discount; this.stockQty = stockQty;
        this.unit = unit; this.imagePath = imagePath;
    }
    public double getFinalPrice() { return price * (1 - discount / 100.0); }
}
