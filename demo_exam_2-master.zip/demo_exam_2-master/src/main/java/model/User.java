package model;

public class User {
    private final int id;
    private final String login;
    private final String fullName;
    private final String role;

    public User(int id, String login, String fullName, String role) {
        this.id = id; this.login = login; this.fullName = fullName; this.role = role;
    }
    public String getFullName() { return fullName; }
    public String getRole() { return role; }
    public boolean isGuest() { return "Гость".equals(role); }
    public boolean isClient() { return "Авторизированный клиент".equals(role); }
    public boolean isManager() { return "Менеджер".equals(role); }
    public boolean isAdmin() { return "Администратор".equals(role); }
}
