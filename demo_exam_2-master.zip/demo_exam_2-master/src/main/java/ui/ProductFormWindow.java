package ui;

import datebase.DBConnection;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Product;
import util.ImageResizer;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductFormWindow {
    // 🔧 Убраны final, чтобы инициализация работала на всех ветках конструктора
    private Stage stage;
    private Product product;
    private Runnable onSaved;

    // Singleton для защиты от открытия двух окон редактирования
    private static ProductFormWindow instance;

    // Поля формы
    private final TextField nameField = new TextField();
    private final TextField skuField = new TextField();
    private final TextArea descArea = new TextArea();
    private final ComboBox<String> categoryCombo = new ComboBox<>();
    private final ComboBox<String> manufacturerCombo = new ComboBox<>();
    private final ComboBox<String> supplierCombo = new ComboBox<>();
    private final TextField priceField = new TextField();
    private final TextField unitField = new TextField();
    private final TextField stockField = new TextField();
    private final TextField discountField = new TextField();
    private final TextField imagePathField = new TextField();
    private final ImageView preview = new ImageView();
    private final Label idLabel = new Label();

    public ProductFormWindow(Stage stage, Product product, Runnable onSaved) {
        // 🔧 1. Сначала всегда инициализируем поля (компилятор доволен)
        this.stage = stage;
        this.product = product;
        this.onSaved = onSaved;

        // 🔧 2. Проверяем, не открыто ли уже окно
        if (instance != null && instance.stage != null && instance.stage.isShowing()) {
            instance.stage.toFront();
            return;
        }

        // 🔧 3. Регистрируем текущий экземпляр как активный
        instance = this;
        stage.setOnCloseRequest(e -> {
            if (instance == this) instance = null;
        });
    }

    public void show() {
        GridPane form = new GridPane();
        form.setHgap(10); form.setVgap(10); form.setPadding(new Insets(20));
        form.setAlignment(Pos.CENTER);
        form.setStyle("-fx-background-color: #fafafa;");

        if (product != null) {
            idLabel.setText("ID: " + product.id);
            idLabel.setStyle("-fx-font-weight: bold;");
            form.add(idLabel, 0, 0, 2, 1);
        }

        form.add(new Label("Артикул*:"), 0, 1);
        skuField.setDisable(product != null);
        form.add(skuField, 1, 1);

        form.add(new Label("Наименование*:"), 0, 2);
        form.add(nameField, 1, 2);

        form.add(new Label("Описание:"), 0, 3);
        descArea.setPrefRowCount(3);
        form.add(descArea, 1, 3);

        loadComboBoxes();
        form.add(new Label("Категория*:"), 0, 4); form.add(categoryCombo, 1, 4);
        form.add(new Label("Производитель*:"), 0, 5); form.add(manufacturerCombo, 1, 5);
        form.add(new Label("Поставщик*:"), 0, 6); form.add(supplierCombo, 1, 6);

        form.add(new Label("Цена*:"), 0, 7); form.add(priceField, 1, 7);
        form.add(new Label("Ед. изм.*:"), 0, 8); form.add(unitField, 1, 8);
        form.add(new Label("Остаток*:"), 0, 9); form.add(stockField, 1, 9);
        form.add(new Label("Скидка % (0-100):"), 0, 10); form.add(discountField, 1, 10);

        HBox imageBox = new HBox(10);
        Button browseBtn = new Button("Выбрать фото");
        preview.setFitWidth(100); preview.setFitHeight(67); preview.setStyle("-fx-border-color: #ccc;");
        imagePathField.setPrefWidth(200); imagePathField.setEditable(false);
        imageBox.getChildren().addAll(browseBtn, imagePathField, preview);
        form.add(new Label("Фото:"), 0, 11);
        form.add(imageBox, 1, 11);

        Button saveBtn = new Button("Сохранить");
        Button cancelBtn = new Button("Отмена");
        HBox buttons = new HBox(15, saveBtn, cancelBtn);
        buttons.setAlignment(Pos.CENTER_RIGHT);
        form.add(buttons, 1, 12);

        // Заполнение при редактировании
        if (product != null) {
            skuField.setText(product.sku);
            nameField.setText(product.name);
            descArea.setText(product.description);
            categoryCombo.setValue(product.category);
            manufacturerCombo.setValue(product.manufacturer);
            supplierCombo.setValue(product.supplier);
            priceField.setText(String.valueOf(product.price));
            unitField.setText(product.unit);
            stockField.setText(String.valueOf(product.stockQty));
            discountField.setText(String.valueOf(product.discount));
            imagePathField.setText(product.imagePath);
            if (product.imagePath != null && !product.imagePath.isEmpty()) {
                File f = new File(product.imagePath);
                if (f.exists()) preview.setImage(new Image(f.toURI().toString()));
            }
        } else {
            discountField.setText("0");
            imagePathField.setText("./resources/picture.png");
            preview.setImage(new Image("file:./resources/picture.png"));
        }

        browseBtn.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg"));
            File selected = fc.showOpenDialog(stage);
            if (selected != null) {
                try {
                    String savedPath = ImageResizer.resizeAndSave(selected, "./resources");
                    imagePathField.setText(savedPath);
                    preview.setImage(new Image(new File(savedPath).toURI().toString()));
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка", "Не удалось обработать изображение", ex.getMessage());
                }
            }
        });

        saveBtn.setOnAction(e -> {
            if (validate()) {
                save();
                if (stage != null) stage.close();
            }
        });

        cancelBtn.setOnAction(e -> {
            if (stage != null) stage.close();
        });

        if (stage != null) {
            stage.setScene(new Scene(form, 500, 550));
            stage.setTitle(product == null ? "Добавить товар" : "Редактировать товар");
            stage.setResizable(false);
            stage.show();
        }
    }

    private void loadComboBoxes() {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            loadCombo(stmt, "SELECT DISTINCT name FROM categories ORDER BY name", categoryCombo);
            loadCombo(stmt, "SELECT DISTINCT name FROM manufacturers ORDER BY name", manufacturerCombo);
            loadCombo(stmt, "SELECT DISTINCT name FROM suppliers ORDER BY name", supplierCombo);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка БД", "Не удалось загрузить справочники", e.getMessage());
        }
    }

    private void loadCombo(Statement stmt, String sql, ComboBox<String> combo) throws SQLException {
        combo.getItems().clear();
        try (ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) combo.getItems().add(rs.getString("name"));
        }
    }

    private boolean validate() {
        List<String> errors = new ArrayList<>();
        if (skuField.getText().isBlank()) errors.add("Артикул обязателен");
        if (nameField.getText().isBlank()) errors.add("Наименование обязательно");
        if (categoryCombo.getValue() == null) errors.add("Выберите категорию");
        if (manufacturerCombo.getValue() == null) errors.add("Выберите производителя");
        if (supplierCombo.getValue() == null) errors.add("Выберите поставщика");
        if (unitField.getText().isBlank()) errors.add("Единица измерения обязательна");

        try {
            double price = Double.parseDouble(priceField.getText());
            if (price < 0) errors.add("Цена не может быть отрицательной");
        } catch (NumberFormatException e) { errors.add("Неверный формат цены"); }

        try {
            int stock = Integer.parseInt(stockField.getText());
            if (stock < 0) errors.add("Остаток не может быть отрицательным");
        } catch (NumberFormatException e) { errors.add("Неверный формат остатка"); }

        try {
            double disc = discountField.getText().trim().isEmpty() ? 0 : Double.parseDouble(discountField.getText());
            if (disc < 0 || disc > 100) errors.add("Скидка должна быть от 0 до 100");
        } catch (NumberFormatException e) { errors.add("Неверный формат скидки"); }

        if (!errors.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Ошибка валидации", "Исправьте ошибки:", String.join("\n", errors));
            return false;
        }
        return true;
    }

    private void save() {
        try (Connection conn = DBConnection.getConnection()) {
            double disc = discountField.getText().trim().isEmpty() ? 0 : Double.parseDouble(discountField.getText());

            if (product == null) {
                String sql = "INSERT INTO products (sku, name, description, category_id, manufacturer_id, supplier_id, price, unit, stock_qty, discount, image_path) VALUES (?, ?, ?, (SELECT id FROM categories WHERE name=?), (SELECT id FROM manufacturers WHERE name=?), (SELECT id FROM suppliers WHERE name=?), ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, skuField.getText().trim());
                    ps.setString(2, nameField.getText().trim());
                    ps.setString(3, descArea.getText().trim());
                    ps.setString(4, categoryCombo.getValue());
                    ps.setString(5, manufacturerCombo.getValue());
                    ps.setString(6, supplierCombo.getValue());
                    ps.setDouble(7, Double.parseDouble(priceField.getText()));
                    ps.setString(8, unitField.getText().trim());
                    ps.setInt(9, Integer.parseInt(stockField.getText()));
                    ps.setDouble(10, disc);
                    ps.setString(11, imagePathField.getText().isEmpty() ? "./resources/picture.png" : imagePathField.getText());
                    ps.executeUpdate();
                }
            } else {
                String sql = "UPDATE products SET name=?, description=?, category_id=(SELECT id FROM categories WHERE name=?), manufacturer_id=(SELECT id FROM manufacturers WHERE name=?), supplier_id=(SELECT id FROM suppliers WHERE name=?), price=?, unit=?, stock_qty=?, discount=?, image_path=? WHERE sku=?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, nameField.getText().trim());
                    ps.setString(2, descArea.getText().trim());
                    ps.setString(3, categoryCombo.getValue());
                    ps.setString(4, manufacturerCombo.getValue());
                    ps.setString(5, supplierCombo.getValue());
                    ps.setDouble(6, Double.parseDouble(priceField.getText()));
                    ps.setString(7, unitField.getText().trim());
                    ps.setInt(8, Integer.parseInt(stockField.getText()));
                    ps.setDouble(9, disc);
                    ps.setString(10, imagePathField.getText().isEmpty() ? "./resources/picture.png" : imagePathField.getText());
                    ps.setString(11, product.sku);
                    ps.executeUpdate();
                }
            }
            if (onSaved != null) onSaved.run();
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Товар сохранён", "");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка БД", "Не удалось сохранить товар", e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}