package ui;

import datebase.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Product;
import model.User;
import service.DatabaseService;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductListWindow {
    private final Stage stage;
    private final User currentUser;
    private final DatabaseService db = new DatabaseService();
    private final TableView<Product> table = new TableView<>();
    private final TextField searchField = new TextField();
    private final ComboBox<String> filterCombo = new ComboBox<>();
    private final Label welcomeLabel = new Label();
    private final ObservableList<Product> products = FXCollections.observableArrayList();

    public ProductListWindow(Stage stage, User user) {
        this.stage = stage;
        this.currentUser = user;
    }

    public void show() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // 1️⃣ ВЕРХНЯЯ ПАНЕЛЬ (ФИО + Выход)
        HBox topBar = new HBox(15);
        topBar.setAlignment(Pos.CENTER_RIGHT);
        welcomeLabel.setText("👤 " + currentUser.getFullName());
        welcomeLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        Button logoutBtn = new Button("Выход");
        logoutBtn.setOnAction(e -> {
            stage.close();
            new AuthWindow(new Stage()).show();
        });
        topBar.getChildren().addAll(welcomeLabel, logoutBtn);
        root.setTop(topBar);

        // 2️⃣ ПАНЕЛЬ УПРАВЛЕНИЯ (Поиск + Фильтр)
        VBox controls = new VBox(10);
        controls.setPadding(new Insets(5, 0, 10, 0));
        filterCombo.getItems().add("Все производители");
        searchField.setPromptText("Поиск по названию, артикулу, описанию...");

        if (currentUser.isManager() || currentUser.isAdmin()) {
            Label filterLabel = new Label("Фильтр по производителю:");
            controls.getChildren().addAll(filterLabel, filterCombo, searchField);
            loadManufacturers();
        }

        // 3️⃣ ТАБЛИЦА ТОВАРОВ
        setupTable();
        VBox mainContainer = new VBox(10, controls, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setCenter(mainContainer);

        // 4️⃣ КНОПКИ АДМИНИСТРАТОРА (Добавить / Удалить)
        if (currentUser.isAdmin()) {
            addAdminButtons(root);
        }

        // 5️⃣ REAL-TIME СЛУШАТЕЛИ
        searchField.textProperty().addListener((obs, oldVal, newVal) -> loadProducts());
        filterCombo.valueProperty().addListener((obs, oldVal, newVal) -> loadProducts());

        stage.setScene(new Scene(root, 1100, 650));
        stage.setTitle("Список товаров | " + currentUser.getRole());
        stage.show();
        loadProducts();
    }

    // 🔹 Загрузка списка производителей для фильтра
    private void loadManufacturers() {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DISTINCT name FROM manufacturers ORDER BY name")) {
            while (rs.next()) filterCombo.getItems().add(rs.getString("name"));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Не удалось загрузить производителей", e.getMessage());
        }
        filterCombo.setValue("Все производители");
    }

    // 🔹 Загрузка товаров с учётом поиска и фильтра
    private void loadProducts() {
        String search = (currentUser.isManager() || currentUser.isAdmin()) ? searchField.getText() : null;
        String manufacturer = filterCombo.getValue();
        products.setAll(db.getProducts(search, manufacturer));
    }

    // 🔹 Настройка таблицы, ячеек и сортировки
    private void setupTable() {
        // Фото
        TableColumn<Product, String> colImg = new TableColumn<>("Фото");
        colImg.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().imagePath));
        colImg.setCellFactory(c -> new TableCell<>() {
            protected void updateItem(String img, boolean empty) {
                super.updateItem(img, empty);
                if (empty || img == null) setGraphic(null);
                else {
                    File f = new File(img);
                    Image image = f.exists() ? new Image(f.toURI().toString(), 50, 50, true, true)
                            : new Image("file:./resources/picture.png");
                    setGraphic(new ImageView(image));
                }
            }
        });
        colImg.setPrefWidth(60); colImg.setSortable(false);

        // Текстовые колонки
        TableColumn<Product, String> colSku = createTextCol("Артикул", p -> p.sku);
        TableColumn<Product, String> colName = createTextCol("Наименование", p -> p.name);
        TableColumn<Product, String> colCat = createTextCol("Категория", p -> p.category);
        TableColumn<Product, String> colDesc = createTextCol("Описание", p -> p.description);
        TableColumn<Product, String> colMan = createTextCol("Производитель", p -> p.manufacturer);
        TableColumn<Product, String> colSup = createTextCol("Поставщик", p -> p.supplier);
        TableColumn<Product, String> colUnit = createTextCol("Ед. изм.", p -> p.unit);

        // Цена с перечёркиванием
        TableColumn<Product, Double> colPrice = new TableColumn<>("Цена");
        colPrice.setCellValueFactory(d -> new javafx.beans.property.SimpleObjectProperty<>(d.getValue().price));
        colPrice.setCellFactory(c -> new TableCell<>() {
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) setText(null);
                else {
                    Product p = getTableRow().getItem();
                    if (p == null) { setText(null); return; }
                    Text original = new Text(String.format("%.2f ₽", p.price));
                    if (p.discount > 0) { original.setStrikethrough(true); original.setFill(Color.RED); }
                    Text finalP = new Text(String.format("%.2f ₽", p.getFinalPrice()));
                    finalP.setFill(Color.BLACK);
                    HBox box = new HBox(5, original, finalP);
                    setGraphic(box); setText(null);
                }
            }
        });

        // Остаток и скидка (с сортировкой)
        TableColumn<Product, Integer> colStock = new TableColumn<>("Остаток");
        colStock.setCellValueFactory(d -> new javafx.beans.property.SimpleIntegerProperty(d.getValue().stockQty).asObject());
        TableColumn<Product, Double> colDisc = new TableColumn<>("Скидка %");
        colDisc.setCellValueFactory(d -> new javafx.beans.property.SimpleObjectProperty<>(d.getValue().discount));

        // ✅ Включаем сортировку для числовых колонок
        colPrice.setSortable(true); colStock.setSortable(true); colDisc.setSortable(true);
        table.getSortOrder().add(colPrice); // Сортировка по цене по умолчанию

        table.getColumns().addAll(colImg, colSku, colName, colCat, colDesc, colMan, colSup, colPrice, colUnit, colStock, colDisc);
        table.setItems(products);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // 🔥 Подсветка строк по ТЗ
        table.setRowFactory(tv -> new TableRow<>() {
            protected void updateItem(Product item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) setStyle("");
                else if (item.stockQty == 0) setStyle("-fx-background-color: #ADD8E6;"); // Голубой
                else if (item.discount > 12) setStyle("-fx-background-color: #F4A460;"); // Оранжевый
                else setStyle("");
            }
        });

        // Двойной клик → редактирование (только для админа)
        table.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && currentUser.isAdmin()) {
                Product selected = table.getSelectionModel().getSelectedItem();
                if (selected != null) new ProductFormWindow(new Stage(), selected, this::loadProducts).show();
            }
        });
    }

    // Вспомогательный метод для текстовых колонок
    private TableColumn<Product, String> createTextCol(String title, java.util.function.Function<Product, String> getter) {
        TableColumn<Product, String> col = new TableColumn<>(title);
        col.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(getter.apply(d.getValue())));
        return col;
    }

    // 🔹 Кнопки добавления и удаления (ТОЛЬКО ДЛЯ АДМИНА)
    private void addAdminButtons(BorderPane root) {
        HBox controlBar = new HBox(15);
        controlBar.setPadding(new Insets(10, 0, 0, 0));
        controlBar.setAlignment(Pos.CENTER_LEFT);

        Button addBtn = new Button("➕ Добавить товар");
        Button deleteBtn = new Button("🗑 Удалить товар");
        addBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
        deleteBtn.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-font-weight: bold;");

        addBtn.setOnAction(e -> new ProductFormWindow(new Stage(), null, this::loadProducts).show());

        deleteBtn.setOnAction(e -> {
            Product selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert(Alert.AlertType.WARNING, "Внимание", "Выберите товар в таблице для удаления", "");
                return;
            }

            // Проверка: есть ли товар в заказах
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM order_items WHERE product_sku = ?")) {
                ps.setString(1, selected.sku);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        showAlert(Alert.AlertType.ERROR, "Удаление невозможно",
                                "Товар \"" + selected.name + "\" присутствует в активных заказах.\nСначала удалите позиции из заказов.", "");
                        return;
                    }
                }
            } catch (SQLException ex) {
                showAlert(Alert.AlertType.ERROR, "Ошибка БД", "Не удалось проверить привязку к заказам", ex.getMessage());
                return;
            }

            // Подтверждение удаления
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Подтверждение удаления");
            confirm.setHeaderText("Удалить товар \"" + selected.name + "\"?");
            confirm.setContentText("Это действие нельзя отменить. Артикул: " + selected.sku);
            if (confirm.showAndWait().get() == ButtonType.OK) {
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement("DELETE FROM products WHERE sku = ?")) {
                    ps.setString(1, selected.sku);
                    ps.executeUpdate();
                    loadProducts();
                    showAlert(Alert.AlertType.INFORMATION, "Успех", "Товар успешно удалён", "");
                } catch (SQLException ex) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка", "Не удалось удалить товар", ex.getMessage());
                }
            }
        });

        controlBar.getChildren().addAll(addBtn, deleteBtn);
        root.setBottom(controlBar);
    }

    // 🔹 Универсальный диалог
    private void showAlert(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}