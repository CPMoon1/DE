package ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.User;
import service.DatabaseService;

import java.awt.*;

public class AuthWindow {
    private final Stage stage;
    private final DatabaseService db = new DatabaseService();

    public AuthWindow(Stage stage) { this.stage = stage; }

    public void show() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label title = new Label("Вход в систему");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        TextField loginField = new TextField(); loginField.setPromptText("Логин");
        PasswordField passField = new PasswordField(); passField.setPromptText("Пароль");
        Button btnLogin = new Button("Войти");
        Button btnGuest = new Button("Войти как Гость");
        Label error = new Label(); error.setStyle("-fx-text-fill: red;");

        btnLogin.setOnAction(e -> {
            User u = db.authenticate(loginField.getText().trim(), passField.getText().trim());
            if (u != null) openMain(u);
            else error.setText("Неверный логин или пароль");
        });
        btnGuest.setOnAction(e -> openMain(new User(0, "guest", "Гость", "Гость")));

        root.getChildren().addAll(title, loginField, passField, btnLogin, btnGuest, error);
        stage.setScene(new Scene(root, 350, 280));
        stage.setTitle("Авторизация");
        stage.show();
    }

    private void openMain(User user) {
        stage.close();
        new ProductListWindow(new Stage(), user).show();
    }
}
