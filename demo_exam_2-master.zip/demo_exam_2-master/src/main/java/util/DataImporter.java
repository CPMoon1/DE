package util;

import java.io.*;
import java.nio.charset.Charset;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class DataImporter {
    private final Connection conn;
    private final Map<String, Integer> roleCache = new HashMap<>();
    private final Map<String, Integer> categoryCache = new HashMap<>();
    private final Map<String, Integer> manufacturerCache = new HashMap<>();
    private final Map<String, Integer> supplierCache = new HashMap<>();
    private final Map<String, Integer> pickupCache = new HashMap<>();
    private final Map<String, Integer> userLoginCache = new HashMap<>();

    public DataImporter(Connection conn) {
        this.conn = conn;
    }

    // Очистка от кавычек, которые Excel добавляет к полям с запятыми
    private String clean(String s) {
        return s == null ? "" : s.trim().replaceAll("^\"|\"$", "");
    }

    public void initCaches() throws SQLException {
        loadCache("roles", "name", roleCache);
        loadCache("categories", "name", categoryCache);
        loadCache("manufacturers", "name", manufacturerCache);
        loadCache("suppliers", "name", supplierCache);
        loadCache("pickup_points", "address", pickupCache);
        loadCache("users", "login", userLoginCache);
    }

    private void loadCache(String table, String col, Map<String, Integer> cache) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT id, " + col + " FROM " + table);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) cache.put(rs.getString(col), rs.getInt("id"));
        }
    }

    public void importAll(String folderPath) throws Exception {
        initCaches();
        importUsers(folderPath + "/users.csv");
        importPickupPoints(folderPath + "/pickup_points.csv");
        importProducts(folderPath + "/products.csv");
        importOrders(folderPath + "/orders.csv");
        System.out.println("✅ Импорт завершён успешно.");
    }

    private void importUsers(String path) throws Exception {
        String sql = "INSERT OR IGNORE INTO users (login, password, full_name, role_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             BufferedReader br = new BufferedReader(
                     new InputStreamReader(new FileInputStream(path), Charset.forName("windows-1251")))) {

            br.readLine(); // Пропуск заголовка
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = splitCsvLine(line);
                if (parts.length < 4) continue;

                String role = clean(parts[0]);
                String fullName = clean(parts[1]);
                String login = clean(parts[2]);
                String password = clean(parts[3]);

                Integer roleId = roleCache.get(role);
                if (roleId == null) roleId = getOrCreateId("roles", "name", role, roleCache);

                ps.setString(1, login);
                ps.setString(2, password);
                ps.setString(3, fullName);
                ps.setInt(4, roleId);
                ps.executeUpdate();
            }
        }
        loadCache("users", "login", userLoginCache);
    }

    private void importPickupPoints(String path) throws Exception {
        String sql = "INSERT OR IGNORE INTO pickup_points (address) VALUES (?)";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             BufferedReader br = new BufferedReader(
                     new InputStreamReader(new FileInputStream(path), Charset.forName("windows-1251")))) {

            String line;
            while ((line = br.readLine()) != null) {
                String addr = clean(line);
                if (addr.isEmpty()) continue;
                ps.setString(1, addr);
                ps.executeUpdate();
            }
        }
        loadCache("pickup_points", "address", pickupCache);
    }

    private void importProducts(String path) throws Exception {
        String sql = "INSERT OR IGNORE INTO products (sku, name, description, category_id, manufacturer_id, supplier_id, unit, price, stock_qty, discount, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             BufferedReader br = new BufferedReader(
                     new InputStreamReader(new FileInputStream(path), Charset.forName("windows-1251")))) {

            br.readLine(); // Пропуск заголовка
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = splitCsvLine(line);
                if (p.length < 11) continue;

                String sku = clean(p[0]);
                String name = clean(p[1]);
                String unit = clean(p[2]);
                double price = Double.parseDouble(clean(p[3]));
                String supplier = clean(p[4]);
                String manufacturer = clean(p[5]);
                String category = clean(p[6]);
                double discount = Double.parseDouble(clean(p[7]));
                int stock = Integer.parseInt(clean(p[8]));
                String desc = clean(p[9]);
                String photo = clean(p[10]).isEmpty() ? "./resources/picture.png" : "./resources/" + clean(p[10]);

                int catId = getOrCreateId("categories", "name", category, categoryCache);
                int manId = getOrCreateId("manufacturers", "name", manufacturer, manufacturerCache);
                int supId = getOrCreateId("suppliers", "name", supplier, supplierCache);

                ps.setString(1, sku);
                ps.setString(2, name);
                ps.setString(3, desc);
                ps.setInt(4, catId);
                ps.setInt(5, manId);
                ps.setInt(6, supId);
                ps.setString(7, unit);
                ps.setDouble(8, price);
                ps.setInt(9, stock);
                ps.setDouble(10, discount);
                ps.setString(11, photo);
                ps.executeUpdate();
            }
        }
    }

    private void importOrders(String path) throws Exception {
        String insOrd = "INSERT INTO orders (user_id, pickup_point_id, order_date, delivery_date, status, pickup_code) VALUES (?, ?, ?, ?, ?, ?)";
        String insItem = "INSERT INTO order_items (order_id, product_sku, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement psOrd = conn.prepareStatement(insOrd, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psItem = conn.prepareStatement(insItem);
             BufferedReader br = new BufferedReader(
                     new InputStreamReader(new FileInputStream(path), Charset.forName("windows-1251")))) {

            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = splitCsvLine(line);
                if (p.length < 8) continue;

                String itemsRaw = clean(p[1]);
                String orderDate = clean(p[2]);
                String deliveryDate = clean(p[3]);
                String pickupAddr = clean(p[4]);
                String clientFullName = clean(p[5]);
                String pickupCode = clean(p[6]);
                String status = clean(p[7]);

                Integer userId = findUserIdByFullName(clientFullName);
                Integer ppId;
                // Пробуем прочитать как ID (число), если не выходит — ищем по адресу
                try {
                    ppId = Integer.parseInt(pickupAddr);
                } catch (NumberFormatException e) {
                    ppId = pickupCache.get(pickupAddr);
                }

                if (userId == null || ppId == null) continue;

                psOrd.setInt(1, userId);
                psOrd.setInt(2, ppId);
                psOrd.setString(3, orderDate);
                psOrd.setString(4, deliveryDate);
                psOrd.setString(5, status);
                psOrd.setString(6, pickupCode);
                psOrd.executeUpdate();

                try (ResultSet rsId = psOrd.getGeneratedKeys()) {
                    if (rsId.next()) {
                        int newOrderId = rsId.getInt(1);
                        String[] parts = itemsRaw.split(",");
                        for (int i = 0; i < parts.length - 1; i += 2) {
                            String sku = clean(parts[i]);
                            int qty = Integer.parseInt(clean(parts[i + 1]));
                            psItem.setInt(1, newOrderId);
                            psItem.setString(2, sku);
                            psItem.setInt(3, qty);
                            psItem.executeUpdate();
                        }
                    }
                }
            }
        }
    }

    private Integer findUserIdByFullName(String fullName) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM users WHERE full_name = ?")) {
            ps.setString(1, fullName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        }
        return null;
    }

    private String[] splitCsvLine(String line) {
        return line.contains(";") ? line.split(";") : line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
    }

    private int getOrCreateId(String table, String col, String value, Map<String, Integer> cache) throws SQLException {
        if (cache.containsKey(value)) return cache.get(value);

        try (PreparedStatement ps = conn.prepareStatement("INSERT OR IGNORE INTO " + table + " (" + col + ") VALUES (?)")) {
            ps.setString(1, value);
            ps.executeUpdate();
        }

        int id = -1;
        try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM " + table + " WHERE " + col + "=?")) {
            ps.setString(1, value);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) id = rs.getInt("id");
            }
        }
        cache.put(value, id);
        return id;
    }
}