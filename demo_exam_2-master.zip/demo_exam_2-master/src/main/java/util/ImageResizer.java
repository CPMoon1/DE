package util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class ImageResizer {
    private static final int MAX_WIDTH = 300;
    private static final int MAX_HEIGHT = 200;

    public static String resizeAndSave(File sourceFile, String targetDir) throws IOException {
        if (!sourceFile.exists()) return "./resources/picture.png";

        BufferedImage original = ImageIO.read(sourceFile);
        if (original == null) return "./resources/picture.png";

        // Пропорциональное масштабирование с ограничением
        int w = original.getWidth();
        int h = original.getHeight();
        double ratio = Math.min((double) MAX_WIDTH / w, (double) MAX_HEIGHT / h);
        int newW = (int) (w * ratio);
        int newH = (int) (h * ratio);

        BufferedImage resized = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.drawImage(original, 0, 0, newW, newH, null);
        g2d.dispose();

        // Сохраняем в целевую папку
        File targetFolder = new File(targetDir);
        if (!targetFolder.exists()) targetFolder.mkdirs();
        File targetFile = new File(targetDir + "/" + sourceFile.getName());
        ImageIO.write(resized, "jpg", targetFile);

        return "./resources/" + sourceFile.getName();
    }
}
