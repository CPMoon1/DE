
import datebase.DBConnection;
import datebase.DatabaseSchema;
import javafx.application.Application;
import javafx.stage.Stage;
import ui.AuthWindow;
import util.DataImporter;

import java.sql.Connection;
import java.sql.Statement;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            stmt.execute("PRAGMA foreign_keys = ON;");

            // ✅ 1. Сначала создаём таблицы
            DatabaseSchema.createTables(conn);

            // ✅ 2. Потом импортируем данные
            java.io.File importFolder = new java.io.File("./import");
            if (importFolder.exists() && importFolder.isDirectory()) {
                new DataImporter(conn).importAll("./import");
            }
        } catch (Exception e) {
            System.err.println("⚠️ Ошибка инициализации БД: " + e.getMessage());
            e.printStackTrace();
        }
        new AuthWindow(stage).show();
    }

    public static void main(String[] args) {
        launch();
    }
}
