@echo off
echo Запуск приложения...
mvn javafx:run
pause